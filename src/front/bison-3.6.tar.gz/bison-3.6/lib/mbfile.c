#include <config.h>
#define MBFILE_INLINE _GL_EXTERN_INLINE
#include "mbfile.h"
